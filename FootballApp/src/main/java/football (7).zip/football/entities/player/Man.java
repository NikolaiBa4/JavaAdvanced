package football.entities.player;

public class Man extends BasePlayer{

    private static final double INITIAL_KILOGRAMS=85.50;
    private static final int INCREASING_RATE=145;

    public Man(String name, String nationality, int strength) {
        super(name, nationality, strength);
    }

    @Override
    public void stimulation(){
        setStrength(getStrength()+INCREASING_RATE);
    }
}
